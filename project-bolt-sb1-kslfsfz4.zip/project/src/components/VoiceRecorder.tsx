import React, { useState, useEffect } from 'react';
import { Mic, Square, Loader } from 'lucide-react';
import { motion } from 'framer-motion';

interface VoiceRecorderProps {
  onRecordingComplete: (text: string) => void;
}

const VoiceRecorder: React.FC<VoiceRecorderProps> = ({ onRecordingComplete }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioChunks, setAudioChunks] = useState<Blob[]>([]);
  const [stream, setStream] = useState<MediaStream | null>(null);

  useEffect(() => {
    let interval: number | null = null;
    
    if (isRecording) {
      interval = window.setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    } else if (!isRecording && recordingTime !== 0) {
      if (interval) clearInterval(interval);
    }
    
    return () => {
      if (interval) clearInterval(interval);
      stopRecording();
    };
  }, [isRecording, recordingTime]);

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const startRecording = async () => {
    try {
      const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setStream(audioStream);
      
      const recorder = new MediaRecorder(audioStream);
      setAudioChunks([]);
      
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          setAudioChunks((chunks) => [...chunks, e.data]);
        }
      };

      recorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        setIsProcessing(true);
        
        // Simulate AI processing with more varied responses
        const mockResponses = [
          "I'm feeling a mix of excitement and anticipation about the upcoming changes. There's this underlying sense of possibility, though I can't help but notice a slight nervousness too.",
          "Today was challenging but enlightening. I realized how much my perspective on work has evolved, and I'm starting to see patterns in how I handle stress.",
          "I've been reflecting on my relationships lately. It's interesting to notice how different interactions affect my energy and emotional state."
        ];
        
        setTimeout(() => {
          setIsProcessing(false);
          onRecordingComplete(mockResponses[Math.floor(Math.random() * mockResponses.length)]);
        }, 2000);
      };

      recorder.start(1000); // Collect data every second
      setMediaRecorder(recorder);
      setIsRecording(true);
      setRecordingTime(0);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Unable to access microphone. Please check your browser permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
    }
    
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    
    setIsRecording(false);
    setMediaRecorder(null);
  };

  return (
    <div className="card flex flex-col items-center p-8 max-w-md mx-auto">
      <h2 className="text-2xl font-serif mb-6 text-center">Speak Your Mind</h2>
      
      <div className="mb-8 w-full text-center">
        {isRecording ? (
          <div className="text-primary font-medium">Recording... {formatTime(recordingTime)}</div>
        ) : isProcessing ? (
          <div className="text-secondary font-medium">Processing your thoughts...</div>
        ) : (
          <div className="text-gray-600">Tap the microphone to start recording</div>
        )}
      </div>
      
      <div className="relative mb-6">
        {isRecording && (
          <motion.div
            className="absolute inset-0 rounded-full"
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.7, 0.3, 0.7],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            style={{ backgroundColor: 'rgba(var(--primary), 0.2)' }}
          />
        )}
        
        {isProcessing ? (
          <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center">
            <Loader className="text-secondary animate-spin" size={32} />
          </div>
        ) : isRecording ? (
          <button
            onClick={stopRecording}
            className="w-20 h-20 rounded-full bg-primary flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300"
          >
            <Square className="text-white" size={32} />
          </button>
        ) : (
          <button
            onClick={startRecording}
            className="w-20 h-20 rounded-full bg-white border-2 border-primary flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 hover:bg-primary/5"
          >
            <Mic className="text-primary" size={32} />
          </button>
        )}
      </div>
      
      <p className="text-sm text-gray-500 text-center max-w-xs">
        Speak freely about your thoughts, feelings, or dreams. Your voice will be analyzed for emotions and patterns.
      </p>
    </div>
  );
};

export default VoiceRecorder;