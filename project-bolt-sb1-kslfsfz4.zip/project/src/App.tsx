import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import JournalPage from './pages/JournalPage';
import InsightsPage from './pages/InsightsPage';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-background text-foreground flex flex-col">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/journal" element={<JournalPage />} />
            <Route path="/insights" element={<InsightsPage />} />
          </Routes>
        </main>
        <footer className="bg-white py-6 border-t">
          <div className="container mx-auto px-4 text-center text-gray-500 text-sm">
            <p>© 2025 MindMirror. All rights reserved.</p>
            <p className="mt-2">Your data is encrypted and never stored. Privacy first.</p>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;